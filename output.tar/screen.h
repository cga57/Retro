#ifndef _SCREEN_
#define _SCREEN_

void Screen_init();
void Screen_shutdown();

#endif
