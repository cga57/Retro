#include <stdio.h>
#include "musicPlayer.h"



void parseWaveFile(char *audioPath, call_back_data *audioData);

void closeFile(call_back_data *audioData);
